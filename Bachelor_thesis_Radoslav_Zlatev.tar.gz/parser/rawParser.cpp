#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>

using namespace std;

bool isN(char ch) {
	return ((int)ch>=48 && (int)ch<=57); 
}

int cnum(string line) {
	int res = 1;
	for (int i=1; i<line.size(); i++)
		if (isN(line[i]) && line[i-1]==' ')
			res++;
	return res;
}

string strnum(int num) {
	string res("");
	stringstream ss;
	ss << num;
	ss >> res;
	
	return res;
}

int extractR(string line) {
	for (int i=0, j=0; i<line.size(); i++) {
		if (line[i]=='r' && !j) j++;
		else if (line[i]=='=' && j==1) j++;
		else if (isN(line[i]) && j==2) ;
		else if (line[i]==' ') ;
		else return -1;
	}

	int id=line.rfind('='), res;
	stringstream ss(line.substr(id+1, line.size()-id));
	ss >> res;

	return res;
}

string exN(string line) {
	int l = line.size();
	if (!l)
		return string("");
	
	bool detected = false;
	string result("");
	for (int i=0; i<l; i++) {
		if (isN(line[i])) {
			result += line[i];
			detected = true;
		}
		else if (detected)
			result += " ";
	} result += "\n";
	cout << result;
	
	return result;
}

int main(int argc, char **argv) {
// manipulate read/write files
	fstream filein, fileout;
	if (argc==2)
		filein.open(argv[1]);
	else
		filein.open("default.hom");
	
	if (!filein) {
		cout << "FILE NOT FOUND!" << endl;
		return 0;
	}
	
	if (argc==3)
		fileout.open(argv[2], ios::out);
	else
		fileout.open("parsed.txt", ios::out);
	
// parsing: detect r
	int r, n, k = 0;
	
	string line(""), firstline;
	while (!line.size())
		getline(filein,line);
	
	r = extractR(line);
	firstline = strnum(r);
	if (r==-1) {
		cout<<"FILE IN WRONG FORMAT"<<endl;
		return 0;
	}
	else
		fileout << firstline;
	
	vector<vector<string> > w;
	
	while(!filein.eof()) {
		vector<string> v;
		
		while (line!="}>" && !filein.eof()) {
			getline(filein, line);
			cout << line << endl;
			v.push_back(line);
		}
		w.push_back(v);
		line = "";
	}
	
	n = w.size()-1;
	fileout << " " << n << endl << endl;

	for (vector<vector<string> >::iterator it=w.begin(); it!=w.end(); it++)
		for (vector<string>::iterator jt=it->begin(); jt!=it->end(); jt++)
			*jt = exN(*jt);

	for (int p=0; p<w.size()-1; p++)
		for (vector<string>::iterator jt=w[p].begin(); jt!=w[p].end(); jt++) {
			if ((*jt).size()==0) {
				w[p].erase(jt);
			}
		}

	for (int i=0; i<w.size()-1; i++) {
		cout << cnum(w[i][0]) << "\n";
		fileout << cnum(w[i][0]) << "\n";
		
		cout << w[i][0];
		fileout << w[i][0];
		
		for (int j=1; j<=r; j++) {
			cout << w[i][j];
			fileout << w[i][j];
		}
		cout << w[i].size()-r-3;
		fileout << w[i].size()-r-3;
		
		for (int j=r+1; j<w[i].size(); j++) {
			cout << w[i][j];
			fileout << w[i][j];
		}	
	}
	
	cout << argc << endl;
	
	return 0;
}
