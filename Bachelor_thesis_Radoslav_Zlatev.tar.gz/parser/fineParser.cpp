#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <cmath>

using namespace std;

vector<pair<int,int> > decompose(int x) {
	vector<int> bin;
	
	for (int i=2, j=x; true; ) {
		if (j==1) break;
		else if (j%i==0) {
			bin.push_back(i);
			j=j/i;
		}
		else i++;
	}
	
	bin.push_back(1);
	vector<pair<int,int> > res;
	
	while (bin.size()>1) {
		int p = bin[0], e = 0;
		for (vector<int>::iterator it=bin.begin(); it!=bin.end(); it++)
			if (*it==p) {
				e++;
				bin.erase(it);
				it--;
			}
			res.push_back(make_pair<int,int>(p, e));
	}

	return res;
}

int main(int argc, char **argv) {
	int r, n, tmp;

	fstream filein, fileout;
	if (argc==2)
		filein.open(argv[1]);
	else
		filein.open("parsed.txt");

	if (!filein) {
		cout << "FILE NOT FOUND!" << endl;
		return 0;
	}

	if (argc==3)
		fileout.open(argv[2], ios::out);
	else
		fileout.open("parsed_final.txt", ios::out);

	filein >> r >> n;
	cout << r << " " << n << endl << endl;
	fileout << r << " " << n << endl << endl;

	for (int i=0; i<n; i++) {
		int size, sizeS, tmp;
		vector<int> orders;
		vector<vector<int> > imgs, S;

		filein >> size;
		for (int j=0; j<size; j++) {
			filein >> tmp;
			orders.push_back(tmp);
		}
		for (int j=0; j<r; j++) {
			vector<int> tmpv;
			for (int k=0; k<size; k++) {
				filein >> tmp;
				tmpv.push_back(tmp);
			}
			imgs.push_back(tmpv);
		}

		filein >> sizeS;
		for (int j=0; j<sizeS; j++) {
			vector<int> tmpv;
			for (int k=0; k<size; k++) {
				filein >> tmp;
				tmpv.push_back(tmp);
			}
			S.push_back(tmpv);
		}
		
		int newSize = 0;
		for (int j=0; j<size; j++) {
			vector<pair<int, int> > da;
			da = decompose(orders[j]);
			newSize += da.size();
		}
		
		fileout << newSize << endl;
		vector<vector<int> > danew;
		for (int j=0; j<size; j++) {
			vector<pair<int, int> > da;
			da = decompose(orders[j]);
			vector<int> supertmp;
			for (int k=0; k<da.size(); k++) {
				fileout << da[k].first << " " << da[k].second << " ";
				int num = (int)pow((double)da[k].first,da[k].second);
				supertmp.push_back(num);
			}
			danew.push_back(supertmp);
		}
		
		fileout << endl;
		for (int j=0; j<r; j++) {
			for (int k=0; k<size; k++) {
				for (int l=0; l<danew[k].size(); l++)
					fileout << (imgs[j])[k]%(danew[k])[l] << " ";
			}
			fileout << endl;
		}
		
		fileout << sizeS << endl;
		for (int j=0; j<sizeS; j++) {
			for (int k=0; k<size; k++) {
				for (int l=0; l<danew[k].size(); l++)
					fileout << (S[j])[k]%(danew[k])[l] << " ";
			}
			fileout << endl;
		}
		
		fileout << endl;
	}

	return 0;
}
