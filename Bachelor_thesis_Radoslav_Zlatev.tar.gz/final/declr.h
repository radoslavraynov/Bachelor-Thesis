#include <iostream>
#include <cmath>
#include <vector>
#include <list>
#include <set>
#include <utility>

#include "bigint.h"

#ifndef _DECLR__H_
#define _DECLR__H_

using std::vector;
using std::set;

typedef vector<unsigned int> grmList;
typedef vector<unsigned int> grmElement;
typedef vector<vector<unsigned int> > grmDList;

typedef RossiBigInt grmLong;
typedef vector<RossiBigInt> grmListLongs;

enum grmDistType {COST, DISTANCE};

class grmGroup {
   private:
	int _r;
	int _numCycGrs;
	int _sizeOfS;

	grmLong _factor;
	grmLong _size;

	grmList _factorSequence;
	
	grmListLongs _orders;
	grmList _primes;
	grmList _powers;

	grmDList _generatorsImgs;
	grmDList _S;

   public:
	grmGroup();
	~grmGroup();

	void set(grmListLongs, grmList, grmList, int, int);
	void setHom(grmDList);
	void setFactor(grmLong);
	void setS(grmDList, int);

	void setFactorSequence(grmList);
	const grmList getFactorSequence();
	
	const grmLong getOrder(int);
	const int getNumCycGrs();
	const int getSizeOfS();
	
	grmList computeFactors();
	const grmLong getSizeOfFactoredS(grmList);
	const grmLong getSizeOfFactoredGr(grmList);
	const grmLong getFactor();
	const grmLong getSize();

	unsigned int getPrimes(int);
	grmList getPrimes();
	unsigned int getPowers(int);
	grmList getPowers();
	
	grmDList getGenImages();
	grmDList getS();

	void print();
	void printS();
};

class grmPath {
  private:
	grmList _sequenceOfNodes;
	grmList _allowedNodes;
	grmLong _s;
	grmLong _cost;
	grmLong B;

  public:
	grmPath();
	~grmPath();
	grmPath(unsigned int);
	grmPath(grmList, grmList, grmLong, grmLong, grmLong);
	const grmLong s();
	const grmLong cost();
	const grmLong getB();
	const bool canExpand(int);
	void expand(unsigned int, grmGroup*, int);
	void print();
	const bool operator <(grmPath);
	const grmList getNodes();
};

struct setOfPathsCompare {
	bool operator() (grmPath p, grmPath q) const {
		return (p.s() <= q.s());
	}
};

class grmSearchTree {
  private:
	set<grmPath, setOfPathsCompare> _paths;
	set<grmLong> _expandedBs;
	grmLong _epselon;
	
	grmList _primes;
	grmList _bounds;
	
	grmGroup *_G;
	int _n;
	
	grmList _solution;

  public:
	grmSearchTree();
	~grmSearchTree();
	grmSearchTree(grmGroup*, int);
	
	const bool expand();
	grmList getSolution();
	void print();
};

class grmFamilyOfMaps {
	private:
		grmGroup *_G;
		int _n;
		unsigned int _r;
		
		grmList _path;
		grmLong B;
		
		grmDList* factoredGens;
		
		set<grmList>* factoredS;
		set<grmListLongs> SQ;
		
	public:
		grmFamilyOfMaps();
		~grmFamilyOfMaps();
		grmFamilyOfMaps(grmGroup*, int, grmList);
		
		grmList map(int, grmListLongs);
		
		void computeFactoredSets();
		set<grmListLongs> computePreimage();
};

#endif
