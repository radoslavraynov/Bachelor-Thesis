#include <iostream>
#include <fstream>
#include <string>
#include <cmath>

#include "declr.h"
#include "funcs.h"

using namespace std;

/* LOADS THE DATA FROM SPECIFICATION FILE */

grmGroup* loader(char *filename, int &n) {
	int r;

	fstream in;
	in.open(filename);
	
	if (!in) {
		cout << "GRM ERROR MSG: NO FILE LOADED!" << endl;
		return NULL;
	}
	
	in >> r >> n;
	
	grmGroup *G = new grmGroup[n];
	
	for (int i=0; i<n; i++) {
		int nc, ns;
		in >> nc;
	
		grmList primes, powers;
		grmListLongs orders;
		unsigned int tmp;
		
		for (int j=0; j<nc; j++) {
			in >> tmp;
			primes.push_back(tmp);

			in >> tmp;
			powers.push_back(tmp);

			grmLong tmp1(primes[j]);
			
			orders.push_back(powBigInt(tmp1, (int)powers[j]));
		}

		G[i].set(orders, primes, powers, nc, r);

		grmDList imgs, S;

		for (int j=0; j<r; j++) {
			grmList tmpList;
			
			for (int k=0; k<nc; k++) {
				in >> tmp;
				tmpList.push_back(tmp);
			}
			imgs.push_back(tmpList);
		}

		G[i].setHom(imgs);

		in >> ns;

		for (int j=0; j<ns; j++) {
			grmList tmpList;
			
			for (int k=0; k<nc; k++) {
				in >> tmp;
				tmpList.push_back(tmp);
			}
			S.push_back(tmpList);
		}

		G[i].setS(S, ns);
	}
	return G;
}

/* CHECKS IF PRIME IS MEBER OF A LIST */

bool isListMember(grmList primeslist, unsigned int prime) {
	if (primeslist.empty())
		return false;
	for (grmList::iterator it=primeslist.begin(); it!=primeslist.end();
it++) {
		if (*it == prime)
			return true;
	}
	return false;
}

/* IMPLEMENTS POW FOR BIGINT TYPE */

grmLong powBigInt(grmLong x, unsigned long y) {
	if (y == 0) {
		grmLong long1(1);
		return long1;
	}
	else if (y == 1)
		return x;
	else
		return x * powBigInt(x, y-1);
}

grmLong gcd(grmLong x, grmLong y) {
	grmLong a = x, b = y, q, r;
	grmLong long0(0);

	while (true) {
		if (b == long0)
			return a;
		else {
			q = a / b;
			r = a - b*q;
			a = b;
			b = r;
		}
	}

	return long0;
}

unsigned int gcd(grmList nl, unsigned int p, unsigned int e) {
	unsigned int r = 0;
	
	for (grmList::iterator it=nl.begin(); it!=nl.end(); it++)
		if (*it == p)
			r++;
	
	r = (r<=e) ? r : e;
	
	return (unsigned int)pow((double)p,(int)r);
}

unsigned int fastgcd(unsigned int x, grmLong y) {
	grmLong z(x), long1(1), long0(0);
	unsigned int res = 1;
	
	while (true) {
		if (y % z == long0) {
			res *= x;
			y = y / z;
		}
		else
			break;
	}
	
	return res;
}

/* IMPLEMENTS THE REAL CHECK IF A SOLUTION IS INDEED OK */

void checkIfIndeedSolution(grmGroup* G, int n, grmList solution) {
	
	
	return;
}

set<grmListLongs> setGenerator(unsigned int p, int r) {
	list<grmListLongs> tmpset(1,grmListLongs());
	
	// generate (Z/pZ)^r
	while ((tmpset.front()).size()<(unsigned int)r) {
		grmListLongs toex = tmpset.front(), tmp;
		for (int i=0; i<(int)p; i++) {
			tmp = toex;
			tmp.push_back(grmLong(i));
			tmpset.push_back(tmp);	
		}
		tmpset.pop_front();
	}
	
	// print (Z/pZ)^r
// 	for (list<grmListLongs>::iterator it=tmpset.begin(); it!=tmpset.end(); it++) {
// 		cout << "( ";
// 		for (grmListLongs::iterator jt=it->begin(); jt!=it->end(); jt++)
// 			cout << *jt << " ";
// 		cout << ")" << endl;
// 	}
	
	set<grmListLongs> res;
	res.insert(tmpset.begin(), tmpset.end());
	
	return res;
}

grmListLongs listGenerator(grmListLongs l, unsigned int p) {
	grmLong long0(0), long1(1), longp(p);
	for (grmListLongs::iterator rit=l.end()-1; rit!=l.begin()-1; rit--) {
		*rit = (*rit + long1) % longp;
		if (*rit != long0) break;
	}
	
	return l;
}

grmListLongs add(grmListLongs l1, grmListLongs l2, grmLong M) {
	for (int i=0; i<(int)l1.size(); i++)
		l1[i] = (l1[i] + l2[i]) % M;
	return l1;
}

grmListLongs mult(grmLong m, grmListLongs l, grmLong M) {
	for (int i=0; i<(int)l.size(); i++)
		l[i] = (m * l[i]) % M;
	return l;
}

void listprint(grmList l) {
	cout << " ( ";
	for (grmList::iterator it=l.begin(); it!=l.end(); it++)
		cout << *it << " ";
	cout << ")";
}

void listprint(grmDList l) {
	cout << " { ";
	for (grmDList::iterator it=l.begin(); it!=l.end(); it++) {
		listprint(*it);
		cout << " ";
	}
	cout << "}" << endl;
}

void listprint(grmListLongs l) {
	cout << " ( ";
	for (grmListLongs::iterator it=l.begin(); it!=l.end(); it++)
		cout << *it << " ";
	cout << ")";
}

void listprint(set<grmListLongs> s) {
	cout << " { ";
	for (set<grmListLongs>::iterator it=s.begin(); it!=s.end(); it++) {
		grmListLongs l = *it;
		listprint(l);
	}
	cout << "}";
}

void listprint(set<grmList> s) {
	cout << " { ";
	for (set<grmList>::iterator it=s.begin(); it!=s.end(); it++) {
		grmList l = *it;
		listprint(l);
	}
	cout << "}";
}
