#include "declr.h"
#include "funcs.h"

using namespace std;

/* grmGroup Implementation */

grmGroup::grmGroup () {
}

grmGroup::~grmGroup () {
}

void grmGroup::set(grmListLongs orders, grmList primes, grmList powers, int numCycGrs, int r) {
	_orders = orders;
	_primes = primes;
	_powers = powers;

	_numCycGrs = numCycGrs;
	_r = r;
	_factor = grmLong(1);
	
	_size = grmLong(0);
	for (int i=0; i<_numCycGrs; i++) _size += _orders[i];
}

void grmGroup::setFactor(grmLong factor) {
	_factor = factor;
}

void grmGroup::setHom(grmDList genIm) {
	_generatorsImgs = genIm;
}

void grmGroup::setFactorSequence(grmList factorSequence) {
	_factorSequence = factorSequence;
}

const grmList grmGroup::getFactorSequence() {
	return _factorSequence;
}

const grmLong grmGroup::getOrder(int i = -1) {
	if (i == -1) {
		grmLong r(_r);
		return r;
	}
	else
		return _orders[i];
}

const grmLong grmGroup::getSize() {
	grmLong size(0);
	
	for (int i=0; i<_numCycGrs; i++)
		size += _orders[i];

	return size;
}

const int grmGroup::getNumCycGrs() {
	return _numCycGrs;
}

const grmLong grmGroup::getFactor() {
	return _factor;
}

const int grmGroup::getSizeOfS() {
	return _sizeOfS;
}

grmList grmGroup::computeFactors() {
	grmList res;
	
	for (int i=0; i<_numCycGrs; i++)
		res.push_back(gcd(_factorSequence, _primes[i], _powers[i]));
	
	return res;
}

const grmLong grmGroup::getSizeOfFactoredS(grmList fctrs) {
	grmLong long0(0);
	grmLong long1(1);

	if (_factor == long1)
		return long1;

	int size = (int)_S.size();
	grmDList T = _S;

	grmList factors = fctrs;			// note that they are ints (in this order)
// 	for (int i=0; i<_numCycGrs; i++) {
// 		grmLong g = fctrs[i];//gcd(_factor, _orders[i]);
// 		factors.push_back(g.get_pure_ulong());
// 	}

	for (grmDList::iterator it=T.begin(); it!=T.end(); it++) {
		for (grmList::iterator jt=it->begin(), jjt=factors.begin(); jt!=it->end(); jt++, jjt++) {
			*jt = (*jt) % (*jjt);
		}
	}

	std::set<grmList> co;
	co.insert(T.begin(), T.end());
	
	size = co.size();
	
// 	for (int i=0; i<(int)T.size(); i++)
// 		for (int j=i+1; j<(int)T.size(); j++)
// 			if (T[i] == T[j]) {
// 				size--;
// 				break;
// 			}

	
	return grmLong(size);
}

const grmLong grmGroup::getSizeOfFactoredGr(grmList fctrs) {
	grmLong size(1);
	
	for (int i=0; i<_numCycGrs; i++)
		size = size * fctrs[i];//gcd(_orders[i], _factor);
	
	return size;
}

unsigned int grmGroup::getPrimes(int i) {
	return _primes[i];
}

grmList grmGroup::getPrimes() {
	return _primes;
}

unsigned int grmGroup::getPowers(int i) {
	return _powers[i];
}

grmList grmGroup::getPowers() {
	return _powers;
}

grmDList grmGroup::getGenImages() {
	return _generatorsImgs;
}

grmDList grmGroup::getS() {
	return _S;
}

void grmGroup::setS(grmDList S, int sizeOfS) {
	_sizeOfS = sizeOfS;
	_S = S;
}

void grmGroup::printS() {
	cout << "Printing group orders and S" << endl;

	for (grmListLongs::iterator iter=_orders.begin(); iter!=_orders.end(); iter++)
		cout << *iter << " ";
	cout << endl << endl;

	for (grmDList::iterator iteri=_S.begin(); iteri!=_S.end(); iteri++) {
		for (grmList::iterator iterj=iteri->begin(); iterj!=iteri->end(); iterj++)
			cout << *iterj << " ";
		cout << endl;
	}
}

void grmGroup::print() {
	cout << "Printing grmGroup:" << endl;
	cout << "  r = "<<_r<<", numCycGrs = "<<_numCycGrs<<", sizeOfS = "<<_sizeOfS << endl;
	cout << "  (Factor = " <<_factor << " )" << endl;
	cout << "Printing primes and powers:" << endl;

	for (grmList::iterator iter=_primes.begin(); iter!=_primes.end(); iter++)
		cout << *iter << " ";
	cout << endl;
	
	for (grmList::iterator iter=_powers.begin(); iter!=_powers.end(); iter++)
		cout << *iter << " ";
	cout << endl;
}

/* grmPath Implementation */

grmPath::grmPath() {
}

grmPath::~grmPath() {
}

grmPath::grmPath(unsigned int node) {
	_sequenceOfNodes.push_back(node);
}

grmPath::grmPath(grmList nodes, grmList allowedNodes, grmLong s, grmLong cost, grmLong factor) {
	_s = s;
	_cost = cost;
	B = factor;

	_sequenceOfNodes=nodes;// .insert(nodes.begin(), nodes.end());
	_allowedNodes=allowedNodes;//.insert(allowedNodes.begin(), allowedNodes.end());
}

const grmLong grmPath::cost() {
	return _cost;
}

const grmLong grmPath::s() {
	return _s;
}

const bool grmPath::operator <(const grmPath b) {
	return (_cost < b._cost);
}

void grmPath::print() {
	cout << "Nodes: ";
	for (grmList::iterator it=_sequenceOfNodes.begin(); it!=_sequenceOfNodes.end(); it++)
		cout << *it << " ";
	
	stringstream ss1, ss2;
	ss1 << this->s();
	ss2 << this->cost();
	
	cout << endl << "  s = " << (ss1.str()).substr(0,(ss1.str()).size()-6);
	if ((ss1.str()).size() <= 6) cout << "<1";
	cout << ", cost = " << (ss2.str()).substr(0,(ss2.str()).size()-6) << endl;
}

const bool grmPath::canExpand(int positionOfPrime) {
	if (_allowedNodes[positionOfPrime] > 0) {
		_allowedNodes[positionOfPrime]--;
		return true;
	}
	else
		return false;
}

void grmPath::expand(unsigned int node, grmGroup* G, int n) {
	_sequenceOfNodes.push_back(node);
	
	grmLong Prod(1000000), longNode(node);
	int r = (int)(((G[0]).getOrder(-1)).get_pure_ulong());
	
	B = B * longNode;
	Prod = Prod * powBigInt(B,r);

	for (int i=0; i<n; i++) {
		(G[i]).setFactor(B);
		(G[i]).setFactorSequence(_sequenceOfNodes);
		grmList fctrs = (G[i]).computeFactors();
		Prod = (Prod * (G[i]).getSizeOfFactoredS(fctrs)) / (G[i]).getSizeOfFactoredGr(fctrs);
	}
	
	_cost = _cost + (_s * powBigInt(longNode, r));
	_s = Prod;
}

const grmLong grmPath::getB() {
	return B;
}

const grmList grmPath::getNodes() {
	return _sequenceOfNodes;
}

/* grmSearchTree Implementation */

grmSearchTree::grmSearchTree() {
	grmLong e(1000);
	_epselon = e;
}

grmSearchTree::~grmSearchTree() {
	delete []_G;
	_G = NULL;
}

grmSearchTree::grmSearchTree(grmGroup* G, int n) {
	grmLong long0(0);
	grmLong long1(1);
	grmLong e(100000);
	
	_epselon = e;
	
	_G = G;
	_n = n;

	grmList primes;
	grmDList powers;
	
	for (int i=0; i<n; i++)
		G[i].print();
		
	for (int i=0; i<n; i++) {
		for (int j=0; j<G[i].getNumCycGrs(); j++) {
			if (!isListMember(primes, G[i].getPrimes(j))) {
				primes.push_back(G[i].getPrimes(j));
				grmList newlist;
				newlist.push_back(G[i].getPowers(j));
				powers.push_back(newlist);
			}
			else {
				int locateIndex;
				for (locateIndex=0; locateIndex<(int)primes.size(); locateIndex++) {
					if (primes[locateIndex] == G[i].getPrimes(j))
						break;
				}
				(powers[locateIndex]).push_back(G[i].getPowers(j));
			}
		}
	}
	
	grmDList boundpowers;
	int r = (int)(((G[0]).getOrder(-1)).get_pure_ulong());
	
	for (int i=0; i<(int)primes.size(); i++) {
		grmList newlist;
		for (int j=0; j<r; j++) {
			unsigned int largest = 0;
			grmList::iterator toDelete;
			for (grmList::iterator it=(powers[i]).begin(); it!=(powers[i]).end(); it++) {
				if (largest < (*it)) {
					largest = (*it);
					toDelete = it;
				}
			}
			if (largest)
				(powers[i]).erase(toDelete);
			newlist.push_back(largest);
		}
		boundpowers.push_back(newlist);
	}
	
	for (grmDList::iterator it=boundpowers.begin(); it!=boundpowers.end(); it++) {
		unsigned int rthPower = (*it)[r-1];
		_bounds.push_back(rthPower);
	}
	_primes.insert(_primes.begin(), primes.begin(), primes.end());
	
	// testing: B'
	printf("computing B': primes and their powers\n");
	for (int i=0; i<(int)_primes.size(); i++)
		printf("  %d -> %d\n", _primes[i], _bounds[i]);

	// order _primes and _bounds resp.
/*	for (int i=0; i<(int)_primes.size()-1; i++) {
		for (int j=i+1; j<(int)_primes.size(); j++) {
			if (_primes[i] > _primes[j]) {
				swap(_primes[i], _primes[j]);
				swap(_bounds[i], _bounds[j]);
			}
		}
	}
	
	// testing: B' (ordered primes)
	printf("computing B': primes and their powers\n");
	for (int i=0; i<(int)_primes.size(); i++)
		printf("  %d -> %d\n", _primes[i], _bounds[i]);
	*/
	
	// initial path
	grmLong longnew1(1000000);
	grmList l; l.push_back(1);
	grmPath initialPath(l, _bounds, longnew1, long0, long1);
	
	_paths.insert(initialPath);
	_expandedBs.insert(long1);
	
	initialPath.print();
	
	grmLong tmpBIG(1);
	for (int i=0; i<(int)_primes.size(); i++)
		tmpBIG = tmpBIG * powBigInt(grmLong(_primes[i]),_bounds[i]);
	
	cout << tmpBIG;
}

const bool grmSearchTree::expand() {
	if (_paths.empty()) {
		cout << "Empty Set" << endl;
		exit(0);
		return false;
	}

	grmPath bestPath = *(_paths.begin());
	_paths.erase(_paths.begin());

	bool newPaths = false;
	
	bestPath.print();
	
	for (int i=0; i<(int)_primes.size(); i++) {
		grmPath newPath = bestPath;
		
		if (newPath.canExpand(i)) {
			newPath.expand(_primes[i], _G, _n);
			bool inserted = _expandedBs.insert(newPath.getB()).second;
			if (inserted) {
				_paths.insert(newPath);
				newPaths = true;
			}
		}
		else {
			// cout << "Cannot expand here!" << endl;
		}
	}
	
	if (newPaths) {
		grmPath toCheck = *(_paths.begin());
		if (toCheck.s() < _epselon) {
			_solution = toCheck.getNodes();
			return true;
		}
	}
	
	return false;
}

void grmSearchTree::print() {
	cout << "====" << endl;
}

grmList grmSearchTree::getSolution() {
	return _solution;
}

/* grmFamilyOfMaps Implementation */

grmFamilyOfMaps::grmFamilyOfMaps() {
}

grmFamilyOfMaps::~grmFamilyOfMaps() {
	delete []_G;
	_G = NULL;
	
	delete []factoredGens;
	factoredGens = NULL;
	
	delete []factoredS;
	factoredS = NULL;
}

grmFamilyOfMaps::grmFamilyOfMaps(grmGroup *G, int n, grmList solution) {
	_n = n;
	_r = ((G[0]).getOrder(-1)).get_pure_ulong();
	_G = G;
	
	_path = solution;
	B = grmLong(_path[1]);	// note that there must be at lest 1 p, p - prime
	
	factoredGens = new grmDList[_n];
	factoredS = new set<grmList>[_n];
	
	// initialize SQ as (Z/qZ)^r
	SQ = setGenerator(_path[1], _r);
	
	// [debug]
// 	cout << "tuk";
// 	listprint(SQ);
// 	cout<<endl;
}

void grmFamilyOfMaps::computeFactoredSets() {
	for (int i=0; i<_n; i++) {
		factoredGens[i].clear();
		factoredS[i].clear();
	}
	
	for (int i=0; i<_n; i++) {
		// possible flaw when computing for very large B's
		// but should be OK if all the group orders are of
		// unsigned int order.
		grmList gcds;
		for (int j=0; j<_G[i].getNumCycGrs(); j++) {
			grmLong d(_G[i].getOrder(j));
			d = gcd(d, B);
			// note that since the group order is in the unsigned int
			// range, the gcd will also be in this range
			gcds.push_back(d.get_pure_ulong());
		}
		
		factoredGens[i] = _G[i].getGenImages();
		for (grmDList::iterator it=factoredGens[i].begin(); it!=factoredGens[i].end(); it++) {
			for (grmList::iterator jt=it->begin(), mt=gcds.begin(); jt!=it->end(); jt++, mt++)
				*jt = *jt % *mt;
		}
		
		grmDList S = _G[i].getS();
		for (grmDList::iterator it=S.begin(); it!=S.end(); it++) {
			for (grmList::iterator jt=it->begin(), mt=gcds.begin(); jt!=it->end(); jt++, mt++)
				*jt = *jt % *mt;
		}
		
		factoredS[i].insert(S.begin(), S.end());
		
		// [debug] assume it on belief (after I have checked it) work
// 		cout<<endl<<i<<", "<<B<<endl;
// 		listprint(factoredS[i]);
	}
	
	return;
}

set<grmListLongs> grmFamilyOfMaps::computePreimage() {
	this->computeFactoredSets();
	set<grmListLongs> SQtmp;
	
	for (set<grmListLongs>::iterator gt=SQ.begin(); gt!=SQ.end(); gt++) {
		grmListLongs g = *gt;
		bool isInAll = true;
		for (int i=0; i<_n; i++) {
			grmList hg = this->map(i,g);
			cout <<endl <<"h_"<<i<<"_(";
			listprint(g);
			cout << ")=" << endl;
			listprint(hg);
			cout << " in ";
			listprint(factoredS[i]);
			pair<set<grmList>::iterator, bool> ret;
			ret = factoredS[i].insert(hg);
			
			if (ret.second == true) {
				// the element was successfully inserted, so was not
				// initially in the set, thus we have to erase it
				factoredS[i].erase(ret.first);
				isInAll = false;
				cout << "Breaks at i="<<i<<endl;
				cout<<endl;
				break;
			}
			else {
				// the element was already in the set,
				// so keep the true value of isInAll
				// and insert it in case it stays true
			}
		}
		if (isInAll)
			SQtmp.insert(g);
	}
	SQ = SQtmp;
	cout << "The elements who survived after the direct computation:";
	listprint(SQ);
	cout << endl;
	
	// put the primes into a list to build Sigma(B)
	grmList primesQueue(_path.begin()+2, _path.end());
	
	// second part: for each g in Sigma(B) check if the lifts to Sigma(pB)
	// are in all the images (Si+pBGi)/pBGi
	for (grmList::iterator it=primesQueue.begin(); it!=primesQueue.end(); it++) {
		grmLong Bold = B;
		B = B * (*it);
		this->computeFactoredSets();
		SQtmp.clear();
		
		for (set<grmListLongs>::iterator gt=SQ.begin(); gt!=SQ.end(); gt++) {
			grmListLongs g = *gt;
			grmListLongs h(_r,grmLong(*it-1)), l;
			
			// compute the lifts: for each h in the generated set,
			// take B*h+g. This gives all the lifts and for each of
			// them check if it maps to all of the images of S_i
			for (int i=0; i<(int)pow((long double)(*it),(int)_r); i++) {
				h = listGenerator(h, *it);
				l = add(mult(Bold, h, B), g, B);
				
				// check if each list is in all the images
				bool isInAll = true;
				for (int i=0; i<_n; i++) {
					grmList hg = this->map(i,g);
					pair<set<grmList>::iterator, bool> ret;
					ret = factoredS[i].insert(hg);
					
					if (ret.second == true) {
						// the element was successfully inserted, so was not
						// initially in the set, thus we have to erase it
						factoredS[i].erase(ret.first);
						isInAll = false;
						break;
					}
					else {
						// the element was already in the set,
						// so keep the true value of isInAll
						// and insert it in case it stays true
					}
				}
				if (isInAll)
					SQtmp.insert(g);
			}
		}
		SQ = SQtmp;
	}

	if (SQ.empty())
		cout << "Horray! The intersection is empty!" << endl;
	else {
		cout << "The intersection is NOT empty! These are the elements:" << endl;
		for (set<grmListLongs>::iterator lt=SQ.begin(); lt!=SQ.end(); lt++) {
			grmListLongs deref = *lt;
			cout << "  ( ";
			for (grmListLongs::iterator et=deref.begin(); et!=deref.end(); et++)
				cout << *et << " ";
			cout << ")" << endl;
		}
	}
	
	return SQ;
}

grmList grmFamilyOfMaps::map(int i, grmListLongs gg) {
	grmList res(_G[i].getNumCycGrs(), 0);
	
	for (int j=0; j<(int)_r; j++) {
		for (grmLong jlong(0); jlong<gg[j]; jlong++) {
			for (int k=0; k<_G[i].getNumCycGrs(); k++) {
				res[k] = (res[k] + factoredGens[i][j][k]) % (gcd(_G[i].getOrder(k),B)).get_pure_ulong();
			}
		}
	}
	return res;
}
