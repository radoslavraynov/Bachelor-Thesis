#include <iostream>
#include <fstream>
#include <string>

#include "declr.h"
#include "funcs.h"

using namespace std;

int main(int argc, char** argv) {
	grmGroup* G = NULL;
	int n, maxDepth = 30, depth = 0;
	char c;

	char* filename = "default.hom";
	if (argc == 2)
		filename = argv[1];
	else if (argc == 3) {
		filename = argv[1];
		stringstream s;
		char* tmp = argv[2];
		s << tmp;
		s >> maxDepth;
	}

	G = loader(filename, n);

	if (!G) {
		cout << "GRM ERROR MSG: CANNOT INITIALIZE THE FAMILY OF GROUP HOMOMORPHISMS!" << endl;
		return 0;
	}
	
	// the search loop
	grmSearchTree T(G, n);
	bool goal = false;
	
	do {
		goal = T.expand();
		T.print();
		depth++;
	} while (!goal && (depth < maxDepth));
	
	if (goal) {
		grmList sol = T.getSolution();
		stringstream ss;
		for (grmList::iterator it=sol.begin(); it!=sol.end(); it++)
			ss << *it << ", ";
		
		cout << "Goal reached (in " << depth << " steps)! Path nodes: " << ss.str() << endl;
		
		cout << "To actually compute the B-set enter \'c\'. To quit enter \'q\'" << endl << "  >> ";
 		cin >> c;
//		c = 'q';
	}
	else {
		cout << "Goal not reached in " << maxDepth << " steps." << endl;
	}

	// if solution is found up to MAX_DEPTH
	if (goal && c == 'c') {
		grmFamilyOfMaps P(G, n, T.getSolution());
		P.computePreimage();
	}

	// testing the second part
// 	grmList pr;
// 	
// 	pr.push_back(1);
// 	pr.push_back(2);
// 	pr.push_back(2);
// 	pr.push_back(2);
// 	pr.push_back(7);
// 	pr.push_back(5);
// 	pr.push_back(11);
// 	pr.push_back(3);
	
// 	grmFamilyOfMaps P(G, n, pr);
// 	P.computePreimage();
	
	// works fine
// 	grmListLongs pr2(4,grmLong(10));
// 	for (grmLong i(0); i<powBigInt(grmLong(11), 2); i++) {
// 		pr2 = listGenerator(pr2, 11);
// 		listprint(pr2);
// 		cout << endl;
// 	}
	
	//listprint(setGenerator(3,4));
	
	return 0;
}
