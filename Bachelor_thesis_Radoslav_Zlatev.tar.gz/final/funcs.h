#include "declr.h"

#ifndef _FUNCS__H_
#define _FUNCS__H_

grmGroup *loader(char*, int&);

bool isListMember(grmList, unsigned int);

grmLong powBigInt(grmLong, unsigned long);

grmLong gcd(grmLong, grmLong);

unsigned int gcd(grmList, unsigned int, unsigned int);

unsigned int fastgcd(unsigned int, grmLong);

void checkIfIndeedSolution(grmGroup*, int, grmList);

set<grmListLongs> setGenerator(unsigned int, int);

grmListLongs listGenerator(grmListLongs, unsigned int);

grmListLongs add(grmListLongs, grmListLongs, grmLong);

grmListLongs mult(grmLong, grmListLongs, grmLong);

void listprint(grmList);

void listprint(grmDList);

void listprint(grmListLongs);

void listprint(set<grmListLongs>);

void listprint(set<grmList>);

#endif
